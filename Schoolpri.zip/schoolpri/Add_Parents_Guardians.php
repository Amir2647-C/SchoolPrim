<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo "";
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $Parent_ID = $_POST['Parent_ID'];
    $Name = $_POST['Name'];
    $Address = $_POST['Address'];
    $Email = $_POST['Email'];
    $Telephone = $_POST['Telephone'];
    $Pupil_ID = $_POST['Pupil_ID'];

    $Parent_ID = mysqli_real_escape_string($conn,$Parent_ID);
    $Name = mysqli_real_escape_string($conn, $Name);
    $Address = mysqli_real_escape_string($conn,$Address);
    $Email = mysqli_real_escape_string($conn,$Email);
    $Telephone = mysqli_real_escape_string($conn,$Telephone);
    $Pupil_ID = mysqli_real_escape_string($conn,$Pupil_ID);
    //Insert Parents data in database
    $sql = "INSERT INTO parents_guardians_table (Parent_ID, Name, Address, Email, Telephone, Pupil_ID) VALUES ('$Parent_ID', '$Name', '$Address', '$Email', '$Telephone', '$Pupil_ID')";
    // Save the Parents/Guardians data and for simplicity, let's just display the class information here
    if ($conn->query($sql) === true) 
    {
    echo "Parents/Guardians Added successfully";
     }
     else {
    echo "Error: ".$sql. "<br>" . $conn->error;
    }
}
     $conn->close();
    
?>
