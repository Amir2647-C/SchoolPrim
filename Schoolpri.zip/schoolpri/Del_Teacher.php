
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {

        die("Connection failed: " . $conn->connect_error);
    }
    
    function deleteTeacher($Teacher_ID, $conn) {


        $sqlDeleteTeacher = "DELETE FROM teacher_table WHERE Teacher_ID = $Teacher_ID";
        $conn->query($sqlDeleteTeacher);
   
    
        if ($conn->error) {
            echo "Error deleting Teacher: " . $conn->error;
        } else {
            echo "Teacher data deleted successfully.";
        }
    }
    
    $teacherIdToDelete = 1;
    deleteTeacher($teacherIdToDelete, $conn);

    $conn->close();
    ?>
    
    

    
    
    
