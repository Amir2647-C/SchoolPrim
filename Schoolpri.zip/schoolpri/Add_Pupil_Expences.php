<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo "" ;
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $Expences_Wallet_ID = $_POST['Expences_Wallet_ID'];
    $Food_Expences = $_POST['Food_Expences'];
    $Transport_Expences = $_POST['Transport_Expences'];
    $Pupil_ID = $_POST['Pupil_ID'];

    $Total_Expences = $Food_Expences + $Transport_Expences;

    $Expences_Wallet_ID = mysqli_real_escape_string($conn,$Expences_Wallet_ID);
    $Food_Expences = mysqli_real_escape_string($conn,$Food_Expences);
    $Transport_Expences = mysqli_real_escape_string($conn,$Transport_Expences);
    $Total_Expences = mysqli_real_escape_string($conn,$Total_Expences);
    $Pupil_ID = mysqli_real_escape_string($conn,$Pupil_ID);
    //Insert Pupil Expences data in database
    $sql = "INSERT INTO pupils_expences_table (Expences_Wallet_ID, Food_Expences, Transport_Expences,Total_Expences, Pupil_ID) VALUES ('$Expences_Wallet_ID', '$Food_Expences', '$Transport_Expences','$Total_Expences', '$Pupil_ID')";
    // Save the Teacher data and for simplicity, let's just display the class information here
    if ($conn->query($sql) === true) 
    {
    echo "Expenses successfully Added";
     }
     else {
    echo "Error: ".$sql. "<br>" . $conn->error;
    }
}
     $conn->close();
    
?>
