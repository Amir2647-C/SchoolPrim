
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {

        die("Connection failed: " . $conn->connect_error);
    }
    
    function deleteParents($Parent_ID, $conn) {


        $sqlDeleteParent = "DELETE FROM parents_guardians_table WHERE Parent_ID = $Parent_ID";
        $conn->query($sqlDeleteParent);
   
    
        if ($conn->error) {
            echo "Error deleting Parents_Guardians: " . $conn->error;
        } else {
            echo "Parent data deleted successfully.";
        }
    }
    
    $ParentIdToDelete = 1;
    deleteParents($ParentIdToDelete, $conn);

    $conn->close();
    ?>
    
    

    
    
    
