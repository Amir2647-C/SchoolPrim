<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo "";
    
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $Class_ID = $_POST['Class_ID'];
    $Class_Name = $_POST['Class_Name'];
    $Capacity = $_POST['Capacity'];

    $Class_ID = mysqli_real_escape_string($conn,$Class_ID);
    $Class_Name = mysqli_real_escape_string($conn, $Class_Name);
    $Capacity = mysqli_real_escape_string($conn,$Capacity);
    
    //Update Class data in database
    $sql = "UPDATE class_table SET Class_Name='$Class_Name', Capacity='$Capacity WHERE Class_ID='$Class_ID'";
    // Save the class data and for simplicity, let's just display the class information here
    if ($conn->query($sql) === true) 
    {
    echo "Class record Updated successfully";
     }
     else {
    echo "Error: ".$sql. "<br>" . $conn->error;
    }
}
     $conn->close();
    
?>
