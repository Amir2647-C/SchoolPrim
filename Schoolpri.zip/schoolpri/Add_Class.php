<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo " ";
    
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $Class_ID = $_POST['Class_ID'];
    $Class_Name = $_POST['Class_Name'];
    $Capacity = $_POST['Capacity'];

    $Class_ID = mysqli_real_escape_string($conn,$Class_ID);
    $Class_Name = mysqli_real_escape_string($conn, $Class_Name);
    $Capacity = mysqli_real_escape_string($conn,$Capacity);
    
    //Add Class data in database
    $sql = "INSERT INTO class_table (Class_ID, Class_Name, Capacity) VALUES ('$Class_ID', '$Class_Name', '$Capacity')";
    // Save the class data and for simplicity, let's just display the class information here
    if ($conn->query($sql) === true) 
    {
    echo "Class registered successfully";
     }
     else {
    echo "Error: ".$sql. "<br>" . $conn->error;
    }
}
     $conn->close();
    
?>
