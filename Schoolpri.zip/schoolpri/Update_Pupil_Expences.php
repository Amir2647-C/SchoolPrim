<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo "" ;
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $Expences_Wallet_ID = $_POST['Expences_Wallet_ID'];
    $Food = $_POST['Food'];
    $Transport = $_POST['Transport'];
    $Pupil_ID = $_POST['Pupil_ID'];

    $Expences_Wallet_ID = mysqli_real_escape_string($conn,$Expences_Wallet_ID);
    $Food_Expences = mysqli_real_escape_string($conn,$Food_Expences);
    $Transport_Expences = mysqli_real_escape_string($conn,$Transport_Expences);
    $Pupil_ID = mysqli_real_escape_string($conn,$Pupil_ID);
    //Update Pupil Expences data in database
    $sql = "UPDATE pupil_table SET Food_Expences='$Food_Expences', Transport_Expences='$Transport_Expences', Pupil_ID='$Pupil_ID' WHERE Expences_Wallet_ID='$Expences_Wallet_ID'";
    // Save the Teacher data and for simplicity, let's just display the class information here
    if ($conn->query($sql) === true) 
    {
    echo "Expenses Updated successfully";
     }
     else {
    echo "Error: ".$sql. "<br>" . $conn->error;
    }
}
     $conn->close();
    
?>
