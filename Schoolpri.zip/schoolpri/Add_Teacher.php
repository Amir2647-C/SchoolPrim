<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo "";
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $Teacher_ID = $_POST['Teacher_ID'];
    $Name = $_POST['Name'];
    $Address = $_POST['Address'];
    $Telephone = $_POST['Telephone'];
    $Salary = $_POST['Salary'];
    $Class_ID = $_POST['Class_ID'];

    $Teacher_ID = mysqli_real_escape_string($conn,$Teacher_ID);
    $Name = mysqli_real_escape_string($conn, $Name);
    $Address = mysqli_real_escape_string($conn,$Address);
    $Telephone = mysqli_real_escape_string($conn,$Telephone);
    $Salary = mysqli_real_escape_string($conn,$Salary);
    $Class_ID = mysqli_real_escape_string($conn,$Class_ID);
    //Insert Teacher data in database
    $sql = "INSERT INTO teacher_table (Teacher_ID, Name, Address, Telephone, Salary, Class_ID) VALUES ('$Teacher_ID', '$Name', '$Address','$Telephone', '$Salary', '$Class_ID')";
    // Save the Teacher data and for simplicity, let's just display the class information here
    if ($conn->query($sql) === true) 
    {
    echo "Teacher registered successfully";
     }
     else {
    echo "Error: ".$sql. "<br>" . $conn->error;
    }
}
     $conn->close();
    
?>
