<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Website</title>
    <style>
        body {
          font-family: Arial, Helvetica, sans-serif;
         background-color: black;
         color: white;
         }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;

        }
        tr:first-child {
           background-color: red;
       }
        tr:not(:first-child) {
           background-color: black;
       }
        tr td {
          color: white;
       }
   
    </style>
 <table>
        <tr>
            <th>Parent ID</th>
            <th>Name</th>
            <th>Address</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Pupil ID</th>
        </tr>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo ""; 
}

$sql = "SELECT * FROM parents_guardians_table";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "
        <tr>
        <th>{$row['Parent_ID']}</th>
        <th>{$row['Name']}</th>
        <th>{$row['Address']}</th>
        <th>{$row['Email']}</th>
        <th>{$row['Telephone']}</th>
        <th>{$row['Pupil_ID']}</th>
        </tr>";
    }
    echo "</tr>";
} else {
    echo "No Parents/Guardians found.";
}
mysqli_close($conn);
?>
</table>

</head>
<body>