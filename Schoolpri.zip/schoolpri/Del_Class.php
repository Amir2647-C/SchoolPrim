
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {

        die("Connection failed: " . $conn->connect_error);
    }
    
    function deleteClass($Class_ID, $conn) {

        $sqlDeleteWallet = "DELETE FROM pupils_expences_table WHERE Pupil_ID IN (SELECT Pupil_ID FROM pupil_table WHERE Class_ID = $Class_ID)";
        $conn->query($sqlDeleteWallet);

        $sqlDeleteParent = "DELETE FROM parents_guardians_table WHERE Pupil_ID IN (SELECT Pupil_ID FROM pupil_table WHERE Class_ID = $Class_ID)";
        $conn->query($sqlDeleteParent);
    
        $sqlDeletePupils = "DELETE FROM pupil_table WHERE Class_ID = $Class_ID";
        $conn->query($sqlDeletePupils);

        $sqlDeleteTeacher = "DELETE FROM teacher_table WHERE Class_ID = $Class_ID";
        $conn->query($sqlDeleteTeacher);
    
        $sqlDeleteClass = "DELETE FROM class_table WHERE Class_ID = $Class_ID";
        $conn->query($sqlDeleteClass);
    
        if ($conn->error) {
            echo "Error deleting class: " . $conn->error;
        } else {
            echo "Class and associated data deleted successfully.";
        }
    }
    
    $classIdToDelete = 1;
    deleteClass($classIdToDelete, $conn);

    $conn->close();
    ?>
    
    
