
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {

        die("Connection failed: " . $conn->connect_error);
    }
    
    function deletePupil($Pupil_ID, $conn) {

    
        $sqlDeletePupilExpensesTable = "DELETE FROM pupils_expences_table WHERE Pupil_ID IN (SELECT Pupil_ID FROM pupil_table WHERE Pupil_ID = $Pupil_ID)";
        $conn->query($sqlDeletePupilExpensesTable);

        $sqlDeleteParent = "DELETE FROM parents_guardians_table WHERE Pupil_ID IN (SELECT Pupil_ID FROM pupil_table WHERE Pupil_ID = $Pupil_ID)";
        $conn->query($sqlDeleteParent);
    
        $sqlDeletePupil = "DELETE FROM pupil_table WHERE Pupil_ID = $Pupil_ID";
        $conn->query($sqlDeletePupil);
    
        if ($conn->error) {
            echo "Error deleting Pupil: " . $conn->error;
        } else {
            echo "Pupil and associated data deleted successfully.";
        }
    }
    
    $PupilIdToDelete = 1;
    deletePupil($PupilIdToDelete, $conn);

    $conn->close();
    ?>
    
    
