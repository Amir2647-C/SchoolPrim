
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {

        die("Connection failed: " . $conn->connect_error);
    }
    
    function deletePupilExpenses($Expences__Wallet_ID, $conn) {


        $sqlDeletePupilExpenses = "DELETE FROM pupils_expences_table WHERE Expences_Wallet_ID = $Expences__Wallet_ID";
        $conn->query($sqlDeletePupilExpenses);
   
    
        if ($conn->error) {
            echo "Error deleting Pupil Expenses: " . $conn->error;
        } else {
            echo "Parent data deleted successfully.";
        }
    }
    
    $ParentIdToDelete = 1;
    deletePupilExpenses($ParentIdToDelete, $conn);

    $conn->close();
    ?>
    
    

    
    
    
