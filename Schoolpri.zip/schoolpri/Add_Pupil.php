<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolpri";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error);
}
else {
    echo "";
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $Pupil_ID = $_POST['Pupil_ID'];
    $Name = $_POST['Name'];
    $Address = $_POST['Address'];
    $Medical_Info = $_POST['Medical_Info'];
    $D_O_B = $_POST['D_O_B'];
    $Email = $_POST['Email'];
    $Class_ID = $_POST['Class_ID'];

    $Pupil_ID = mysqli_real_escape_string($conn,$Pupil_ID);
    $Name = mysqli_real_escape_string($conn, $Name);
    $Address = mysqli_real_escape_string($conn,$Address);
    $Medical_Info = mysqli_real_escape_string($conn,$Medical_Info);
    $D_O_B = mysqli_real_escape_string($conn,$D_O_B);
    $Email = mysqli_real_escape_string($conn,$Email);
    $Class_ID = mysqli_real_escape_string($conn,$Class_ID);

    //Insert Pupil data in database
    $sql = "INSERT INTO pupil_table (Pupil_ID, Name, Address, Medical_Info, D_O_B, Email, Class_ID) VALUES ('$Pupil_ID', '$Name', '$Address','$Medical_Info', '$D_O_B', '$Email', '$Class_ID')";
    // Save the Pupil data and for simplicity, let's just display the class information here
    if ($conn->query($sql) === true) 
    {
    echo "Pupil registered successfully";
     }
     else {
    echo "Error: ".$sql. "<br>" . $conn->error;
    }
}
     $conn->close();
    
?>
